package com.example.moncatch
import android.graphics.Canvas
import android.graphics.Paint
import kotlin.math.hypot
import kotlin.random.Random
data class Monster(var x:Float,var y:Float,val radius:Float,val hue:Float,var alive:Boolean=true){
  private val paint=Paint().apply{ style=Paint.Style.FILL }
  fun draw(canvas:Canvas){
    val hsv=floatArrayOf(hue,0.7f,1f)
    paint.color=android.graphics.Color.HSVToColor(hsv)
    canvas.drawCircle(x,y,radius,paint)
  }
  fun contains(px:Float,py:Float)=hypot((px-x),(py-y))<=radius*1.2f
  companion object{
    fun random(width:Int,height:Int):Monster{
      val r=Random.nextInt(24,48).toFloat()
      val x=Random.nextInt(r.toInt(),width-r.toInt()).toFloat()
      val y=Random.nextInt(r.toInt(),height-r.toInt()).toFloat()
      val hue=Random.nextInt(0,360).toFloat()
      return Monster(x,y,r,hue,true)
    }
  }
}
