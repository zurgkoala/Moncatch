package com.example.moncatch
import android.content.Context
import android.content.SharedPreferences
import android.graphics.*
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class GameView(context: Context): SurfaceView(context), Runnable, SurfaceHolder.Callback{
  private var thread: Thread? = null
  @Volatile private var running=false
  private val gridPaint=Paint().apply{ color=Color.LTGRAY; strokeWidth=2f }
  private val hudPaint=Paint().apply{ color=Color.BLACK; textSize=42f; isAntiAlias=true; typeface=Typeface.DEFAULT_BOLD }
  private val buttonPaint=Paint().apply{ color=Color.argb(180,0,0,0) }
  private val buttonText=Paint().apply{ color=Color.WHITE; textSize=36f; isAntiAlias=true; typeface=Typeface.DEFAULT_BOLD; textAlign=Paint.Align.CENTER }
  private var monsters=mutableListOf<Monster>()
  private var lastSpawn=0L
  private var spawnIntervalMs=2000L
  private var inventory=mutableListOf<Float>()
  private var score=0
  private val prefs: SharedPreferences=context.getSharedPreferences("save", Context.MODE_PRIVATE)
  private var worldOffsetX=0f
  private var worldOffsetY=0f
  private var dragging=false
  private var lastX=0f
  private var lastY=0f
  init{ holder.addCallback(this); load() }
  override fun run(){
    while(running){
      val start=System.currentTimeMillis()
      update(); drawFrame()
      val sleep=max(0,16-(System.currentTimeMillis()-start)).toLong()
      try{ Thread.sleep(sleep) }catch(_:InterruptedException){}
    }
  }
  private fun update(){
    val now=System.currentTimeMillis()
    if(now-lastSpawn>spawnIntervalMs && monsters.size<8 && width>0 && height>0){
      monsters.add(Monster.random(width*2,height*2)); lastSpawn=now
    }
  }
  private fun drawFrame(){
    val canvas=holder.lockCanvas()?:return
    try{
      canvas.drawColor(Color.parseColor("#E8F5E9"))
      val cell=120
      val startX=(-worldOffsetX%cell+cell)%cell
      val startY=(-worldOffsetY%cell+cell)%cell
      for(x in startX.toInt()..width step cell) canvas.drawLine(x.toFloat(),0f,x.toFloat(),height.toFloat(),gridPaint)
      for(y in startY.toInt()..height step cell) canvas.drawLine(0f,y.toFloat(),width.toFloat(),y.toFloat(),gridPaint)
      canvas.save(); canvas.translate(-worldOffsetX,-worldOffsetY)
      monsters.forEach{ if(it.alive) it.draw(canvas) }
      canvas.restore()
      canvas.drawRect(0f,0f,width.toFloat(),120f,Paint().apply{ color=Color.WHITE; alpha=220 })
      canvas.drawText("Caught: ${inventory.size} • Score: $score",24f,72f,hudPaint)
      val btnW=260f; val btnH=100f; val bx=width-btnW-24f; val by=height-btnH-24f
      canvas.drawRoundRect(RectF(bx,by,bx+btnW,by+btnH),24f,24f,buttonPaint)
      canvas.drawText("Release 1",bx+btnW/2,by+btnH/2+12f,buttonText)
    } finally { holder.unlockCanvasAndPost(canvas) }
  }
  override fun onTouchEvent(event: MotionEvent): Boolean{
    val bx=width-260f-24f; val by=height-100f-24f
    val insideButton=event.x in bx..(bx+260f) && event.y in by..(by+100f)
    when(event.actionMasked){
      MotionEvent.ACTION_DOWN -> {
        lastX=event.x; lastY=event.y; dragging=true
        if(!insideButton){
          val wx=event.x+worldOffsetX; val wy=event.y+worldOffsetY
          val target=monsters.firstOrNull{ it.alive && it.contains(wx,wy) }
          if(target!=null){ target.alive=false; inventory.add(target.hue); score+=10; save(); invalidate(); return true }
        }
      }
      MotionEvent.ACTION_MOVE -> {
        if(dragging){
          val dx=event.x-lastX; val dy=event.y-lastY
          worldOffsetX=min(max(0f,worldOffsetX-dx), width.toFloat())
          worldOffsetY=min(max(0f,worldOffsetY-dy), height.toFloat())
          lastX=event.x; lastY=event.y
        }
      }
      MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
        dragging=false
        if(insideButton && inventory.isNotEmpty()){
          val hue=inventory.removeAt(0)
          val m=Monster(worldOffsetX+100f, worldOffsetY+200f, 36f, hue, true)
          monsters.add(m); score=max(0,score-3); save()
        }
      }
    }
    return true
  }
  private fun save(){ prefs.edit().putString("inv", inventory.joinToString(",")).putInt("score",score).apply() }
  private fun load(){
    val arr=prefs.getString("inv","")?:""
    if(arr.isNotEmpty()) inventory = arr.split(",").mapNotNull{ it.toFloatOrNull() }.toMutableList()
    score=prefs.getInt("score",0)
  }
  override fun surfaceCreated(holder: SurfaceHolder){ resume() }
  override fun surfaceChanged(holder: SurfaceHolder, format:Int, width:Int, height:Int){}
  override fun surfaceDestroyed(holder: SurfaceHolder){ pause() }
  fun pause(){ running=false; thread?.join(200) }
  fun resume(){ if(running) return; running=true; thread=Thread(this); thread?.start() }
}
