# MonCatch (Original Monster-Catching Prototype)

This is an original mini game (no Pokémon IP).

## Play loop
- Drag to pan the grid world.
- Tap colored creatures to catch them.
- "Release 1" button puts one back.
- Progress saves locally.

## Build locally or in the cloud

### A) Android Studio (PC/Mac)
Open the project and press Run.

### B) GitHub Actions (from your phone)
1) Create a GitHub repo and upload this whole folder (keep `.github/workflows/android.yml`).  
2) Open the **Actions** tab and run **Build Android APK**.  
3) Download the **app-debug.zip** artifact → unzip → install `app-debug.apk` on your phone.
